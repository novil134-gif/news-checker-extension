let highlightVisible = true;

document.addEventListener('DOMContentLoaded', () => {
  document.getElementById('analyze-btn').addEventListener('click', startAnalysis);
  document.getElementById('toggle-btn').addEventListener('click', toggleHighlight);

  // 이미 분석된 탭이면 상태 복원
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_STATE' }, (res) => {
      if (chrome.runtime.lastError || !res) return;
      if (res.analyzed) {
        showStats(res.stats);
        document.getElementById('btn-icon').textContent = '✓';
        document.getElementById('btn-text').textContent = '다시 분석하기';
        highlightVisible = res.visible;
        updateToggleBtn();
      }
    });
  });
});

function setProgress(pct, msg) {
  const wrap = document.getElementById('progress-wrap');
  wrap.style.display = 'block';
  document.getElementById('progress-fill').style.width = pct + '%';
  document.getElementById('progress-text').textContent = msg;
}

function showError(msg) {
  const el = document.getElementById('error-msg');
  el.textContent = msg; el.style.display = 'block';
  setTimeout(() => el.style.display = 'none', 4000);
}

function showStats(stats) {
  document.getElementById('c-fact').textContent    = stats.fact || 0;
  document.getElementById('c-opinion').textContent = stats.opinion || 0;
  document.getElementById('c-manip').textContent   = stats.manipulation || 0;
  document.getElementById('c-neutral').textContent = stats.neutral || 0;
  document.getElementById('stats-grid').style.display = 'grid';
  document.getElementById('toggle-btn').style.display = 'block';
}

function updateToggleBtn() {
  document.getElementById('toggle-btn').textContent =
    highlightVisible ? '하이라이트 끄기' : '하이라이트 켜기';
}

function resetBtn() {
  const btn = document.getElementById('analyze-btn');
  btn.disabled = false;
  document.getElementById('btn-icon').textContent = '▶';
  document.getElementById('btn-text').textContent = '이 페이지 분석하기';
  document.getElementById('progress-wrap').style.display = 'none';
}

async function startAnalysis() {
  const btn = document.getElementById('analyze-btn');
  btn.disabled = true;
  document.getElementById('btn-icon').textContent = '⟳';
  document.getElementById('btn-text').textContent = '분석 중...';
  document.getElementById('error-msg').style.display = 'none';
  setProgress(20, '기사 텍스트 추출 중...');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) { showError('탭을 찾을 수 없습니다.'); resetBtn(); return; }

    setProgress(50, '패턴 분석 중...');

    chrome.tabs.sendMessage(tabs[0].id, { type: 'EXTRACT_AND_ANALYZE' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        showError('분석 실패 — 뉴스 기사 페이지에서 시도해주세요.');
        resetBtn(); return;
      }
      if (!res.success) {
        showError(res.error || '텍스트를 찾을 수 없습니다.');
        resetBtn(); return;
      }

      setProgress(100, `${res.count}개 문장 분석 완료!`);
      showStats(res.stats);
      highlightVisible = true;
      updateToggleBtn();

      document.getElementById('btn-icon').textContent = '✓';
      document.getElementById('btn-text').textContent = '다시 분석하기';
      btn.disabled = false;
      setTimeout(() => document.getElementById('progress-wrap').style.display = 'none', 1500);
    });
  });
}

function toggleHighlight() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'TOGGLE_HIGHLIGHT' }, (res) => {
      if (chrome.runtime.lastError || !res) return;
      highlightVisible = res.visible;
      updateToggleBtn();
    });
  });
}
