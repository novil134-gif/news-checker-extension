// ============================================================
// 규칙 기반 뉴스 신뢰도 분석기 — API 완전 무료
// ============================================================

const PATTERNS = {

  // ── 팩트 지표 ──
  fact: {
    patterns: [
      /(\d+)[%％]/,                                          // 수치+퍼센트
      /\d+[조억만천백]\s*원/,                                // 금액
      /\d{4}년\s*\d{1,2}월/,                                // 날짜
      /에\s*따르면|에\s*의하면|발표했다|밝혔다|공개했다/,
      /통계청|기획재정부|국토부|교육부|행안부|국세청/,
      /자료에\s*따르면|보고서에\s*따르면|조사에\s*따르면/,
      /연구\s*결과|실험\s*결과|조사\s*결과/,
      /공식\s*발표|공식\s*확인|확인됐다|확인되었다/,
      /\d+명|제\d+조|총\s*\d+/,
      /서울시|정부는|국회는|대법원|헌법재판소/,
    ],
    weight: 1.5
  },

  // ── 의견·주장 지표 ──
  opinion: {
    patterns: [
      /것으로\s*(보인다|예상된다|전망된다|분석된다)/,
      /주장했다|강조했다|역설했다|피력했다/,
      /전문가[는들은]\s*(말|지적|분석|전망|평가)/,
      /~(할|될)\s*것으로/,
      /평가[했다됐다]|분석[했다됐다]|전망[했다됐다]/,
      /라고\s*(말했다|밝혔다|전했다|했다)/,
      /의견[이을을]|견해[를을]|입장[을을]/,
      /예상[된다됩니다했다]|전망[된다됩니다했다]/,
      /인터뷰에서|기자에게|취재진에|기자회견/,
      /교수는|박사는|원장은|대표는|위원장은/,
    ],
    weight: 1.2
  },

  // ── 감정 조작 지표 ──
  manipulation: {
    patterns: [
      /충격적|경악|분노|참담|처참|비참|끔찍|혐오/,
      /최악의|최고의 적|매국|반역|배신|내로남불/,
      /절대\s*(안\s*된다|해서는\s*안)/,
      /결코\s*(용납|허용|묵과)/,
      /완전히\s*(망했|무너졌|끝났|파탄)/,
      /적폐|친일|친북|좌빨|빨갱이|수꼴|토착왜구/,
      /국민을\s*(우롱|기만|농락|속이)/,
      /나라가\s*(망한다|끝난다|무너진다)/,
      /진정한\s*(애국자|국민|시민)/,
      /이렇게\s*(무능한|파렴치한|뻔뻔한)/,
      /분명히\s*(잘못됐다|틀렸다|거짓이다)/,
      /도대체|어떻게\s*(감히|이럴\s*수)/,
      /경악을\s*금치|기가\s*막힌|어이가\s*없/,
    ],
    weight: 2.0
  }
};

// 문장 분리
function splitSentences(text) {
  return text
    .replace(/([.!?。！？])\s+/g, '$1\n')
    .split('\n')
    .map(s => s.trim())
    .filter(s => s.length > 10 && s.length < 500);
}

// 문장 하나 분석
function analyzeSentence(sentence) {
  const scores = { fact: 0, opinion: 0, manipulation: 0 };

  for (const [type, config] of Object.entries(PATTERNS)) {
    for (const pattern of config.patterns) {
      if (pattern.test(sentence)) {
        scores[type] += config.weight;
      }
    }
  }

  const max = Math.max(...Object.values(scores));

  if (max === 0) {
    return { type: 'neutral', reason: '특별한 지표 없음 — 중립적 서술', score: 0 };
  }

  const type = Object.entries(scores).find(([, v]) => v === max)[0];

  const reasons = {
    fact: '수치·공식 출처·발표 표현 포함',
    opinion: '주관적 평가·예측·인용 표현 포함',
    manipulation: '감정 자극·낙인·극단적 표현 포함'
  };

  return { type, reason: reasons[type], score: max };
}

// 전체 분석
function analyzeText(text) {
  const sentences = splitSentences(text);
  return sentences.map(sentence => ({
    text: sentence,
    ...analyzeSentence(sentence)
  }));
}

// 모듈 내보내기 (content.js에서 직접 사용)
if (typeof module !== 'undefined') module.exports = { analyzeText };
