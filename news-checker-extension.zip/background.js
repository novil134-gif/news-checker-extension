chrome.runtime.onInstalled.addListener(() => {
  console.log('뉴스 신뢰도 판별기 설치 완료');
});
