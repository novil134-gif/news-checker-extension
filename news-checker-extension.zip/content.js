(() => {
  let state = { analyzed: false, visible: true, sentences: [], stats: {} };
  let tooltip = null;

  // ============================================================
  // 규칙 기반 분석기 (API 불필요 — 완전 무료)
  // ============================================================
  const PATTERNS = {
    fact: {
      weight: 1.5,
      patterns: [
        /(\d+)[%％]/,
        /\d+[조억만천백]\s*원/,
        /\d{4}년\s*\d{1,2}월/,
        /에\s*따르면|에\s*의하면|발표했다|밝혔다|공개했다/,
        /통계청|기획재정부|국토부|교육부|행안부|국세청|법무부|외교부/,
        /자료에\s*따르면|보고서에\s*따르면|조사에\s*따르면/,
        /연구\s*결과|실험\s*결과|조사\s*결과/,
        /공식\s*발표|공식\s*확인|확인됐다|확인되었다/,
        /\d+명이|\d+건|총\s*\d+/,
        /서울시|정부는|국회는|대법원|헌법재판소|감사원/,
        /GDP|CPI|기준금리|환율|코스피|코스닥/,
        /세계보건기구|WHO|UN|IMF|OECD/,
      ]
    },
    opinion: {
      weight: 1.2,
      patterns: [
        /것으로\s*(보인다|예상된다|전망된다|분석된다|풀이된다)/,
        /주장했다|강조했다|역설했다|피력했다|촉구했다/,
        /전문가[는들]\s*(말|지적|분석|전망|평가|우려)/,
        /평가[했됐]|분석[했됐]|전망[했됐]|우려[했됐]/,
        /라고\s*(말했다|밝혔다|전했다|했다|덧붙였다)/,
        /의견[이을]|견해[를을]|입장[을을]/,
        /예상[된됩했]|전망[된됩했]/,
        /인터뷰에서|기자에게|취재진에|기자회견에서/,
        /교수는|박사는|원장은|대표는|위원장은|연구원은/,
        /~할\s*것|~될\s*것|~일\s*수\s*있/,
        /보여진다|여겨진다|여겨지고|보인다/,
      ]
    },
    manipulation: {
      weight: 2.0,
      patterns: [
        /충격적|경악|분노|참담|처참|비참|끔찍|혐오/,
        /최악의|완전히\s*망|파탄|무너졌|끝났다/,
        /절대\s*(안\s*된다|해서는\s*안)/,
        /결코\s*(용납|허용|묵과)/,
        /적폐|내로남불|친일|친북/,
        /국민을\s*(우롱|기만|농락|속이)/,
        /나라가\s*(망한다|끝난다|무너진다)/,
        /진정한\s*(애국자|국민|시민)이라면/,
        /이렇게\s*(무능한|파렴치한|뻔뻔한)/,
        /도대체|어떻게\s*(감히|이럴\s*수)/,
        /경악을\s*금치|기가\s*막힌|어이가\s*없/,
        /역대급\s*(최악|실패|참사)/,
        /이\s*정부는|그\s*정권은/,
        /세금\s*도둑|혈세\s*낭비/,
      ]
    }
  };

  function splitSentences(text) {
    return text
      .replace(/([.!?。！？])\s+/g, '$1|||')
      .split('|||')
      .map(s => s.trim())
      .filter(s => s.length > 8 && s.length < 600);
  }

  function analyzeSentence(sentence) {
    const scores = { fact: 0, opinion: 0, manipulation: 0 };
    for (const [type, config] of Object.entries(PATTERNS)) {
      for (const pat of config.patterns) {
        if (pat.test(sentence)) scores[type] += config.weight;
      }
    }
    const max = Math.max(...Object.values(scores));
    if (max === 0) return { type: 'neutral', reason: '특별한 편향 지표 없음' };
    const type = Object.keys(scores).reduce((a, b) => scores[a] > scores[b] ? a : b);
    const reasons = {
      fact: '수치·공식출처·발표 표현 감지',
      opinion: '주관적 평가·예측·인용 표현 감지',
      manipulation: '감정자극·낙인·극단적 표현 감지'
    };
    return { type, reason: reasons[type] };
  }

  function runAnalysis(text) {
    const sentences = splitSentences(text);
    return sentences.map(text => ({ text, ...analyzeSentence(text) }));
  }

  // ============================================================
  // 툴팁
  // ============================================================
  function createTooltip() {
    if (tooltip) return;
    tooltip = document.createElement('div');
    tooltip.id = 'nfc-tooltip';
    document.body.appendChild(tooltip);
    document.addEventListener('scroll', () => {
      if (tooltip) tooltip.style.display = 'none';
    }, { passive: true });
  }

  function showTooltip(e, type, reason) {
    if (!tooltip) createTooltip();
    const labels = { fact: '✅ 팩트 기반', opinion: '💬 의견·주장', manipulation: '⚠️ 감정 조작', neutral: '○ 중립·맥락' };
    tooltip.innerHTML = `<strong>${labels[type] || type}</strong><br>${reason || ''}`;
    tooltip.style.display = 'block';
    moveTooltip(e);
  }

  function moveTooltip(e) {
    if (!tooltip) return;
    const x = e.clientX + window.scrollX + 14;
    const y = e.clientY + window.scrollY - 52;
    tooltip.style.left = Math.min(x, window.scrollX + window.innerWidth - 270) + 'px';
    tooltip.style.top = Math.max(y, window.scrollY + 8) + 'px';
  }

  function hideTooltip() {
    if (tooltip) tooltip.style.display = 'none';
  }

  // ============================================================
  // 텍스트 추출
  // ============================================================
  function extractArticleText() {
    const selectors = [
      'article', '[role="main"]',
      '.article-body', '.article-content', '.article_body',
      '.news-content', '.news-body', '.news_content',
      '.entry-content', '.post-content', '.story-content',
      '#article-body', '#articleBody', '#newsContent',
      '.cont_article', '.news_view', '.article_view',
      '#dic_area', '.newsct_article', '._article_body_contents'
    ];

    let bestEl = null, bestLen = 0;
    for (const sel of selectors) {
      const els = document.querySelectorAll(sel);
      for (const el of els) {
        const len = (el.innerText || '').length;
        if (len > bestLen) { bestLen = len; bestEl = el; }
      }
      if (bestLen > 500) break;
    }

    if (!bestEl || bestLen < 100) {
      const allP = Array.from(document.querySelectorAll('p'))
        .filter(p => (p.innerText || '').length > 40)
        .sort((a, b) => (b.innerText || '').length - (a.innerText || '').length);
      return allP.slice(0, 20).map(p => p.innerText).join(' ');
    }
    return (bestEl.innerText || '').trim();
  }

  // ============================================================
  // 하이라이트 적용
  // ============================================================
  function applyHighlights(sentences) {
    removeHighlights();
    sentences.forEach(({ text, type, reason }) => {
      if (!text || text.length < 6) return;
      wrapText(text, type, reason);
    });
    state.analyzed = true;
    state.visible = true;
    state.sentences = sentences;
    const stats = { fact: 0, opinion: 0, manipulation: 0, neutral: 0 };
    sentences.forEach(s => { if (stats[s.type] !== undefined) stats[s.type]++; });
    state.stats = stats;
  }

  function wrapText(searchText, type, reason) {
    const clean = searchText.trim().replace(/\s+/g, ' ');
    if (clean.length < 6) return;

    const walker = document.createTreeWalker(document.body, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        const p = node.parentElement;
        if (!p) return NodeFilter.FILTER_REJECT;
        const tag = p.tagName.toLowerCase();
        if (['script','style','noscript','head'].includes(tag)) return NodeFilter.FILTER_REJECT;
        if (p.closest('#nfc-tooltip,.nfc-highlight')) return NodeFilter.FILTER_REJECT;
        return NodeFilter.FILTER_ACCEPT;
      }
    });

    const nodes = [];
    let n;
    while ((n = walker.nextNode())) nodes.push(n);

    const searchFrag = clean.slice(0, 20);
    for (const node of nodes) {
      const txt = node.textContent || '';
      const idx = txt.indexOf(searchFrag);
      if (idx === -1) continue;
      try {
        const range = document.createRange();
        range.setStart(node, idx);
        const end = Math.min(idx + clean.length, txt.length);
        range.setEnd(node, end);

        const span = document.createElement('span');
        span.className = `nfc-highlight nfc-${type}`;
        span.addEventListener('mouseenter', e => showTooltip(e, type, reason));
        span.addEventListener('mousemove', moveTooltip);
        span.addEventListener('mouseleave', hideTooltip);
        range.surroundContents(span);
        break;
      } catch (e) {}
    }
  }

  function removeHighlights() {
    document.querySelectorAll('.nfc-highlight').forEach(el => {
      const p = el.parentNode;
      if (p) { while (el.firstChild) p.insertBefore(el.firstChild, el); p.removeChild(el); }
    });
  }

  function toggleHighlightVisibility() {
    const els = document.querySelectorAll('.nfc-highlight');
    if (state.visible) { els.forEach(el => el.classList.add('nfc-hidden')); state.visible = false; }
    else { els.forEach(el => el.classList.remove('nfc-hidden')); state.visible = true; }
    return state.visible;
  }

  // ============================================================
  // 메시지 핸들러
  // ============================================================
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_AND_ANALYZE') {
      const text = extractArticleText();
      if (!text || text.length < 20) {
        sendResponse({ success: false, error: '텍스트 추출 실패' });
        return true;
      }
      const sentences = runAnalysis(text);
      applyHighlights(sentences);
      sendResponse({ success: true, stats: state.stats, count: sentences.length });
      return true;
    }

    if (message.type === 'EXTRACT_TEXT') {
      sendResponse({ text: extractArticleText() });
      return true;
    }

    if (message.type === 'APPLY_HIGHLIGHTS') {
      applyHighlights(message.sentences);
      sendResponse({ success: true });
      return true;
    }

    if (message.type === 'TOGGLE_HIGHLIGHT') {
      sendResponse({ visible: toggleHighlightVisibility() });
      return true;
    }

    if (message.type === 'GET_STATE') {
      sendResponse(state);
      return true;
    }
  });

  createTooltip();
})();
