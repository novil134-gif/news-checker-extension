// ============================================================
// 뉴스 표현 분석 엔진 v2.1 — API 없이 브라우저 안에서만 동작
// - 팩트 / 의견 / 감정표현을 단일 라벨이 아닌 복합 점수로 계산
// - 판별 이유, 감지 표현, 신뢰도, 기사 전체 요약 제공
// ============================================================

(function (global) {
  'use strict';

  const CATEGORY_META = {
    fact: {
      label: '팩트 기반',
      emoji: '✅',
      reason: '수치·출처·공식 발표 표현이 포함됨'
    },
    opinion: {
      label: '의견·주장',
      emoji: '💬',
      reason: '예측·평가·주장·인용 표현이 포함됨'
    },
    manipulation: {
      label: '감정 자극',
      emoji: '⚠️',
      reason: '공포·분노·낙인·극단 표현이 포함됨'
    },
    neutral: {
      label: '중립·맥락',
      emoji: '○',
      reason: '강한 판별 지표가 감지되지 않음'
    }
  };

  const PATTERNS = {
    fact: [
      {
        name: '구체적 수치·단위',
        weight: 1.4,
        regex: /(?:\d{1,3}(?:,\d{3})+|\d+)(?:\.\d+)?\s*(?:%|％|명|건|곳|개|원|달러|억원|조원|년|월|일|시간|분|초|㎞|km|㎡|평|톤|배럴|포인트|bp|명분|차례)/i
      },
      {
        name: '날짜·시점',
        weight: 1.0,
        regex: /\d{4}\s*년\s*\d{1,2}\s*월|\d{1,2}\s*월\s*\d{1,2}\s*일|지난\s*\d{1,2}\s*일|오늘\s*(오전|오후)?\s*\d{0,2}\s*시?/
      },
      {
        name: '공식 기관',
        weight: 1.5,
        regex: /통계청|기획재정부|국토교통부|국토부|교육부|행정안전부|행안부|국세청|법무부|외교부|보건복지부|질병관리청|금융위원회|금감원|한국은행|감사원|대법원|헌법재판소|국회|정부|서울시|경찰청|검찰|선관위/
      },
      {
        name: '국제·연구 기관',
        weight: 1.2,
        regex: /세계보건기구|WHO|UN|IMF|OECD|세계은행|WTO|국제에너지기구|IEA|학회|연구원|연구소|대학\s*연구팀/
      },
      {
        name: '자료·보고서 근거',
        weight: 1.4,
        regex: /자료에\s*따르면|보고서에\s*따르면|조사에\s*따르면|통계에\s*따르면|공시에\s*따르면|논문에\s*따르면|연구\s*결과|실험\s*결과|조사\s*결과|분석\s*결과/
      },
      {
        name: '공식 발표·확인',
        weight: 1.3,
        regex: /공식\s*(발표|확인|집계)|발표했다|공개했다|확인됐다|확인되었다|집계됐다|집계되었다|공시했다|의결했다|처리했다|통과시켰다|시행한다/
      },
      {
        name: '법령·제도 근거',
        weight: 1.1,
        regex: /제\s*\d+\s*조|시행령|시행규칙|법률안|개정안|조례|고시|공고|입법예고|판결|결정문|심의|의결/
      },
      {
        name: '시장·경제 지표',
        weight: 1.0,
        regex: /GDP|CPI|물가상승률|기준금리|환율|코스피|코스닥|나스닥|다우지수|S&P\s*500|유가|국채금리|실업률|고용률/i
      }
    ],

    opinion: [
      {
        name: '예측·전망',
        weight: 1.3,
        regex: /것으로\s*(보인다|예상된다|전망된다|분석된다|풀이된다|관측된다)|전망[된됩했]|예상[된됩했]|관측[된됩했]|내다봤다|점쳐진다/
      },
      {
        name: '주장·요구',
        weight: 1.3,
        regex: /주장했다|강조했다|역설했다|피력했다|촉구했다|요구했다|비판했다|반박했다|지적했다|호소했다|경고했다|우려했다/
      },
      {
        name: '전문가·관계자 견해',
        weight: 1.2,
        regex: /전문가[는들]?|관계자[는들]?|업계[는의]?|정치권[은의]?|시장[은의]?|교수는|박사는|원장은|대표는|위원장은|연구원은|애널리스트는/
      },
      {
        name: '인용·발언',
        weight: 1.1,
        regex: /라고\s*(말했다|밝혔다|전했다|했다|덧붙였다|설명했다|주장했다)|이라며|라며|인터뷰에서|기자에게|취재진에|기자회견에서/
      },
      {
        name: '평가·해석',
        weight: 1.1,
        regex: /평가[했됐]|분석[했됐]|해석[했됐]|진단[했됐]|의미로\s*풀이|가능성이\s*(크다|높다|있다)|여겨진다|보여진다|보인다/
      },
      {
        name: '의견 표시어',
        weight: 1.0,
        regex: /의견|견해|입장|논평|사설|칼럼|개인적|주관적|해석|평론/
      }
    ],

    manipulation: [
      {
        name: '강한 감정어',
        weight: 2.0,
        regex: /충격적|충격|경악|분노|참담|처참|비참|끔찍|소름|공포|패닉|불안\s*확산|혐오|배신감|참사|논란\s*폭발|발칵|난리/
      },
      {
        name: '극단적 단정',
        weight: 1.9,
        regex: /최악의|역대급\s*(최악|실패|참사|논란)|완전히\s*(망했|무너졌|끝났|파탄)|나라가\s*(망한다|끝난다|무너진다)|경제가\s*(파탄|붕괴)/
      },
      {
        name: '절대화 표현',
        weight: 1.5,
        regex: /절대\s*(안\s*된다|해서는\s*안|용납할\s*수\s*없)|결코\s*(용납|허용|묵과)|반드시\s*(심판|처벌|막아야)/
      },
      {
        name: '낙인·멸칭',
        weight: 2.1,
        regex: /적폐|매국|반역|친일|친북|좌빨|빨갱이|수꼴|토착왜구|내로남불|세금\s*도둑|혈세\s*낭비|기득권\s*카르텔/
      },
      {
        name: '분노 유도',
        weight: 1.8,
        regex: /국민을\s*(우롱|기만|농락|속이)|어이가\s*없|기가\s*막힌|경악을\s*금치|도대체|어떻게\s*(감히|이럴\s*수)|뻔뻔|파렴치|무능한/
      },
      {
        name: '편 가르기',
        weight: 1.5,
        regex: /진정한\s*(애국자|국민|시민)이라면|상식적인\s*국민이라면|국민의\s*이름으로|이\s*정부는|그\s*정권은|저들|그들만의/
      },
      {
        name: '선정적 제목 표현',
        weight: 1.1,
        regex: /단독|속보|충격\s*고백|믿기\s*힘든|알고\s*보니|결국|드러났다|숨겨진|실체|민낯/
      }
    ]
  };

  function normalizeText(text) {
    return String(text || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[\t\r\n]+/g, ' ')
      .replace(/\s+/g, ' ')
      .trim();
  }

  function splitLongSentence(sentence) {
    const clean = normalizeText(sentence);
    if (clean.length <= 600) return [clean];

    const parts = clean.split(/[,;；]\s+/).map(normalizeText).filter(Boolean);
    const chunks = [];
    let buf = '';

    for (const part of parts) {
      if ((buf + ' ' + part).trim().length > 500 && buf) {
        chunks.push(buf.trim());
        buf = part;
      } else {
        buf = (buf + ' ' + part).trim();
      }
    }
    if (buf) chunks.push(buf.trim());

    return chunks.length ? chunks : clean.match(/.{1,500}/g);
  }

  function splitSentences(text) {
    const decimalDot = '∯DOT∯';
    const cleaned = String(text || '')
      .replace(/\r/g, '\n')
      .replace(/(\d)\.(\d)/g, `$1${decimalDot}$2`)
      .replace(/[\t ]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n');

    const sentences = [];
    const lines = cleaned.split(/\n+/).map(s => s.trim()).filter(Boolean);

    for (const line of lines) {
      const units = line.match(/[^.!?。！？]+[.!?。！？]+(?:["'”’)]*)|[^.!?。！？]+$/g) || [line];
      for (const unit of units) {
        const restoredUnit = unit.replaceAll(decimalDot, '.');
        for (const chunk of splitLongSentence(restoredUnit)) {
          const clean = normalizeText(chunk);
          if (clean.length >= 8 && clean.length <= 700) sentences.push(clean);
        }
      }
    }

    // 같은 문장이 광고·관련기사 영역에서 반복되는 경우를 줄이기 위해 완전 중복만 제거
    const seen = new Set();
    return sentences.filter(s => {
      if (seen.has(s)) return false;
      seen.add(s);
      return true;
    });
  }

  function collectMatches(sentence) {
    const matches = { fact: [], opinion: [], manipulation: [] };
    const rawScores = { fact: 0, opinion: 0, manipulation: 0 };

    for (const [type, rules] of Object.entries(PATTERNS)) {
      for (const rule of rules) {
        const result = sentence.match(rule.regex);
        if (!result) continue;
        rawScores[type] += rule.weight;
        matches[type].push({
          name: rule.name,
          weight: rule.weight,
          sample: result[0].slice(0, 40)
        });
      }
    }

    return { rawScores, matches };
  }

  function scoreTo100(score) {
    return Math.min(100, Math.round((score / 7) * 100));
  }

  function confidenceFromScores(rawScores) {
    const sorted = Object.entries(rawScores).sort((a, b) => b[1] - a[1]);
    const max = sorted[0][1];
    const second = sorted[1] ? sorted[1][1] : 0;
    if (max <= 0) return 35;
    const margin = Math.max(0, max - second);
    return Math.min(96, Math.max(50, Math.round(48 + max * 7 + margin * 8)));
  }

  function choosePrimaryType(rawScores) {
    const entries = Object.entries(rawScores).sort((a, b) => b[1] - a[1]);
    if (entries[0][1] <= 0) return 'neutral';

    // 감정 자극 신호가 충분히 강하면 팩트나 인용이 섞여도 우선 경고한다.
    if (rawScores.manipulation >= 2.0 && rawScores.manipulation >= entries[0][1] - 0.8) {
      return 'manipulation';
    }

    return entries[0][0];
  }

  function buildReason(type, matches) {
    if (type === 'neutral') return CATEGORY_META.neutral.reason;
    const top = (matches[type] || []).slice(0, 3);
    if (!top.length) return CATEGORY_META[type].reason;
    const details = top.map(m => `${m.name}${m.sample ? ` “${m.sample}”` : ''}`).join(', ');
    return `${CATEGORY_META[type].reason} — ${details}`;
  }

  function analyzeSentence(sentence) {
    const clean = normalizeText(sentence);
    const { rawScores, matches } = collectMatches(clean);
    const type = choosePrimaryType(rawScores);
    const scores = {
      fact: scoreTo100(rawScores.fact),
      opinion: scoreTo100(rawScores.opinion),
      manipulation: scoreTo100(rawScores.manipulation)
    };

    const secondaryTypes = Object.entries(rawScores)
      .filter(([key, value]) => key !== type && value >= 1.2)
      .sort((a, b) => b[1] - a[1])
      .map(([key]) => key);

    const flags = type === 'neutral'
      ? []
      : (matches[type] || []).map(m => m.name).slice(0, 4);

    return {
      type,
      label: CATEGORY_META[type].label,
      reason: buildReason(type, matches),
      confidence: confidenceFromScores(rawScores),
      scores,
      rawScores,
      flags,
      matches,
      secondaryTypes
    };
  }

  function analyzeText(text) {
    return splitSentences(text).map(sentence => ({
      text: sentence,
      ...analyzeSentence(sentence)
    }));
  }

  function summarizeAnalysis(sentences) {
    const stats = { fact: 0, opinion: 0, manipulation: 0, neutral: 0 };
    const totals = { fact: 0, opinion: 0, manipulation: 0 };

    for (const sentence of sentences) {
      stats[sentence.type] = (stats[sentence.type] || 0) + 1;
      totals.fact += sentence.rawScores?.fact || 0;
      totals.opinion += sentence.rawScores?.opinion || 0;
      totals.manipulation += sentence.rawScores?.manipulation || 0;
    }

    const total = Math.max(sentences.length, 1);
    const ratios = {
      fact: Math.round((stats.fact / total) * 100),
      opinion: Math.round((stats.opinion / total) * 100),
      manipulation: Math.round((stats.manipulation / total) * 100),
      neutral: Math.round((stats.neutral / total) * 100)
    };

    let label = '균형적 기사';
    let message = '강한 감정 자극 문장이 많지 않습니다.';
    if (ratios.manipulation >= 25 || totals.manipulation >= total * 1.1) {
      label = '주의 필요';
      message = '감정 자극·극단 표현 비중이 높습니다. 핵심 주장과 근거를 분리해서 확인하세요.';
    } else if (ratios.opinion >= 35) {
      label = '의견 비중 높음';
      message = '예측·평가·주장 문장이 많습니다. 사실 보도와 해석을 구분해서 읽는 것이 좋습니다.';
    } else if (ratios.fact >= 45) {
      label = '근거 표현 많음';
      message = '수치·기관·공식 발표 표현이 비교적 많이 포함되어 있습니다.';
    }

    const topIssues = sentences
      .filter(s => s.type === 'manipulation' || (s.rawScores?.manipulation || 0) >= 1.8)
      .sort((a, b) => (b.rawScores?.manipulation || 0) - (a.rawScores?.manipulation || 0))
      .slice(0, 5)
      .map(s => ({
        text: s.text,
        type: s.type,
        confidence: s.confidence,
        reason: s.reason,
        flags: s.flags || [],
        scores: s.scores
      }));

    return { total: sentences.length, stats, ratios, totals, label, message, topIssues };
  }

  const api = {
    CATEGORY_META,
    PATTERNS,
    normalizeText,
    splitSentences,
    analyzeSentence,
    analyzeText,
    summarizeAnalysis
  };

  global.NewsAnalyzer = api;
  if (typeof module !== 'undefined') module.exports = api;
})(typeof window !== 'undefined' ? window : globalThis);
