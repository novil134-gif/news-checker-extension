chrome.runtime.onInstalled.addListener(() => {
  console.log('뉴스 표현 분석기 설치 완료');
});
