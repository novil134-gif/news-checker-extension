let highlightVisible = true;

function $(id) {
  return document.getElementById(id);
}

document.addEventListener('DOMContentLoaded', () => {
  $('analyze-btn').addEventListener('click', startAnalysis);
  $('toggle-btn').addEventListener('click', toggleHighlight);

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'GET_STATE' }, (res) => {
      if (chrome.runtime.lastError || !res) return;
      if (res.analyzed) {
        showStats(res.stats, res.summary);
        renderIssues(res.summary?.topIssues || []);
        $('btn-icon').textContent = '✓';
        $('btn-text').textContent = '다시 분석하기';
        highlightVisible = res.visible;
        updateToggleBtn();
      }
    });
  });
});

function setProgress(pct, msg) {
  $('progress-wrap').style.display = 'block';
  $('progress-fill').style.width = pct + '%';
  $('progress-text').textContent = msg;
}

function showError(msg) {
  const el = $('error-msg');
  el.textContent = msg;
  el.style.display = 'block';
  setTimeout(() => { el.style.display = 'none'; }, 5000);
}

function showStats(stats = {}, summary = null) {
  $('c-fact').textContent = stats.fact || 0;
  $('c-opinion').textContent = stats.opinion || 0;
  $('c-manip').textContent = stats.manipulation || 0;
  $('c-neutral').textContent = stats.neutral || 0;
  $('stats-grid').style.display = 'grid';
  $('toggle-btn').style.display = 'block';

  if (summary) {
    $('summary-label').textContent = summary.label || '분석 결과';
    $('summary-total').textContent = `${summary.total || 0}문장`;
    $('summary-message').textContent = summary.message || '';
    $('summary-card').style.display = 'block';
  }
}

function escapeHtml(value) {
  return String(value || '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#039;');
}

function shortText(text, max = 92) {
  const clean = String(text || '').replace(/\s+/g, ' ').trim();
  return clean.length > max ? clean.slice(0, max - 1) + '…' : clean;
}

function renderIssues(issues = []) {
  const box = $('issues-box');
  const list = $('issues-list');

  if (!issues.length) {
    box.style.display = 'none';
    list.innerHTML = '';
    return;
  }

  list.innerHTML = issues.map(item => `
    <div class="issue-item">
      ${escapeHtml(shortText(item.text))}
      <div class="issue-meta">신뢰도 ${escapeHtml(item.confidence || '')}% · ${escapeHtml((item.flags || []).slice(0, 2).join(', ') || '감정 표현 감지')}</div>
    </div>
  `).join('');
  box.style.display = 'block';
}

function updateToggleBtn() {
  $('toggle-btn').textContent = highlightVisible ? '하이라이트 끄기' : '하이라이트 켜기';
}

function resetBtn() {
  const btn = $('analyze-btn');
  btn.disabled = false;
  $('btn-icon').textContent = '▶';
  $('btn-text').textContent = '이 페이지 분석하기';
  $('progress-wrap').style.display = 'none';
}

async function startAnalysis() {
  const btn = $('analyze-btn');
  btn.disabled = true;
  $('btn-icon').textContent = '⟳';
  $('btn-text').textContent = '분석 중...';
  $('error-msg').style.display = 'none';
  setProgress(20, '기사 본문 추출 중...');

  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) {
      showError('현재 탭을 찾을 수 없습니다.');
      resetBtn();
      return;
    }

    setProgress(45, '문장 분리 및 패턴 분석 중...');

    chrome.tabs.sendMessage(tabs[0].id, { type: 'EXTRACT_AND_ANALYZE' }, (res) => {
      if (chrome.runtime.lastError || !res) {
        showError('분석 실패 — 새로고침 후 뉴스 기사 페이지에서 다시 시도해주세요.');
        resetBtn();
        return;
      }
      if (!res.success) {
        showError(res.error || '텍스트를 찾을 수 없습니다.');
        resetBtn();
        return;
      }

      setProgress(100, `${res.count}개 문장 분석 완료`);
      showStats(res.stats, res.summary);
      renderIssues(res.summary?.topIssues || []);
      highlightVisible = true;
      updateToggleBtn();

      $('btn-icon').textContent = '✓';
      $('btn-text').textContent = '다시 분석하기';
      btn.disabled = false;
      setTimeout(() => { $('progress-wrap').style.display = 'none'; }, 1500);
    });
  });
}

function toggleHighlight() {
  chrome.tabs.query({ active: true, currentWindow: true }, (tabs) => {
    if (!tabs[0]) return;
    chrome.tabs.sendMessage(tabs[0].id, { type: 'TOGGLE_HIGHLIGHT' }, (res) => {
      if (chrome.runtime.lastError || !res) return;
      highlightVisible = res.visible;
      updateToggleBtn();
    });
  });
}
