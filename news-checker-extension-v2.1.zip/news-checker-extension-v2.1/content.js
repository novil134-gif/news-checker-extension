(() => {
  'use strict';

  const Analyzer = window.NewsAnalyzer;
  if (!Analyzer) {
    console.warn('[뉴스 판별기] analyzer.js가 먼저 로드되지 않았습니다.');
    return;
  }

  let state = {
    analyzed: false,
    visible: true,
    sentences: [],
    stats: { fact: 0, opinion: 0, manipulation: 0, neutral: 0 },
    summary: null,
    articleLength: 0
  };

  let tooltip = null;
  let articleRoot = null;

  const ARTICLE_SELECTORS = [
    'article', '[role="main"]', 'main',
    '#dic_area', '.newsct_article', '._article_body_contents',
    '#articeBody', '#articleBody', '#article-body', '#newsContent',
    '.article-body', '.article-content', '.article_body', '.article_view', '.article-view',
    '.news-content', '.news-body', '.news_content', '.news_view', '.cont_article',
    '.entry-content', '.post-content', '.story-content', '.view-content', '.article_txt',
    '#contents', '#content'
  ];

  const REMOVE_SELECTORS = [
    'script', 'style', 'noscript', 'iframe', 'canvas', 'svg', 'video', 'audio',
    'button', 'input', 'textarea', 'select', 'form',
    'nav', 'footer', 'aside', 'header',
    '[aria-hidden="true"]', '[hidden]',
    '[class*="comment"]', '[id*="comment"]',
    '[class*="reply"]', '[id*="reply"]',
    '[class*="related"]', '[id*="related"]',
    '[class*="recommend"]', '[id*="recommend"]',
    '[class*="popular"]', '[id*="popular"]',
    '[class*="ranking"]', '[id*="ranking"]',
    '[class*="advert"]', '[id*="advert"]',
    '[class*="ad-"]', '[id*="ad-"]', '.adsbygoogle'
  ].join(',');

  function escapeHtml(value) {
    return String(value || '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function isRejectedTextNode(node) {
    const parent = node.parentElement;
    if (!parent) return true;
    const tag = parent.tagName.toLowerCase();
    if (['script', 'style', 'noscript', 'head', 'title', 'textarea', 'input', 'button', 'select', 'option'].includes(tag)) return true;
    if (parent.closest('#nfc-tooltip,.nfc-highlight')) return true;
    if (parent.closest(REMOVE_SELECTORS)) return true;
    return !node.nodeValue || !node.nodeValue.trim();
  }

  function getCleanText(el) {
    if (!el) return '';
    const clone = el.cloneNode(true);
    clone.querySelectorAll(REMOVE_SELECTORS).forEach(node => node.remove());
    return (clone.innerText || clone.textContent || '')
      .replace(/\u00a0/g, ' ')
      .replace(/[ \t]+/g, ' ')
      .replace(/\n{3,}/g, '\n\n')
      .trim();
  }

  function getLinkTextRatio(el) {
    const total = (el.innerText || '').trim().length || 1;
    const linkText = Array.from(el.querySelectorAll('a'))
      .map(a => a.innerText || '')
      .join(' ')
      .length;
    return linkText / total;
  }

  function scoreArticleCandidate(el) {
    const text = getCleanText(el);
    const len = text.length;
    if (len < 120) return -Infinity;

    const paragraphCount = el.querySelectorAll('p, div, section').length;
    const headingBonus = el.querySelectorAll('h1, h2').length * 120;
    const linkPenalty = getLinkTextRatio(el) * 900;
    const className = `${el.id || ''} ${el.className || ''}`.toLowerCase();
    const badPenalty = /(comment|reply|related|recommend|popular|ranking|footer|header|nav|advert|aside)/.test(className) ? 1000 : 0;

    return len + Math.min(paragraphCount, 30) * 30 + headingBonus - linkPenalty - badPenalty;
  }

  function findArticleRoot() {
    let best = null;
    let bestScore = -Infinity;

    for (const selector of ARTICLE_SELECTORS) {
      const candidates = document.querySelectorAll(selector);
      for (const el of candidates) {
        const score = scoreArticleCandidate(el);
        if (score > bestScore) {
          bestScore = score;
          best = el;
        }
      }
      if (best && getCleanText(best).length > 700) break;
    }

    if (!best || getCleanText(best).length < 250) {
      const paragraphs = Array.from(document.querySelectorAll('p'))
        .filter(p => !p.closest(REMOVE_SELECTORS))
        .filter(p => (p.innerText || '').trim().length > 40);

      const commonRoot = findCommonRoot(paragraphs.slice(0, 30));
      if (commonRoot && getCleanText(commonRoot).length > 250) best = commonRoot;
    }

    return best || document.body;
  }

  function findCommonRoot(elements) {
    if (!elements.length) return null;
    let root = elements[0].parentElement;
    while (root && root !== document.body) {
      if (elements.every(el => root.contains(el))) return root;
      root = root.parentElement;
    }
    return document.body;
  }

  function extractArticleText() {
    articleRoot = findArticleRoot();
    const text = getCleanText(articleRoot);
    state.articleLength = text.length;
    return text;
  }

  // ============================================================
  // 툴팁
  // ============================================================
  function createTooltip() {
    if (tooltip) return;
    tooltip = document.createElement('div');
    tooltip.id = 'nfc-tooltip';
    document.body.appendChild(tooltip);
    document.addEventListener('scroll', () => {
      if (tooltip) tooltip.style.display = 'none';
    }, { passive: true });
  }

  function showTooltip(e, el) {
    if (!tooltip) createTooltip();
    const type = el.dataset.nfcType || 'neutral';
    const label = el.dataset.nfcLabel || type;
    const reason = el.dataset.nfcReason || '';
    const confidence = el.dataset.nfcConfidence || '';
    const scores = el.dataset.nfcScores ? JSON.parse(el.dataset.nfcScores) : null;
    const flags = el.dataset.nfcFlags ? JSON.parse(el.dataset.nfcFlags) : [];

    const scoreLine = scores
      ? `<div class="nfc-tip-score">팩트 ${scores.fact} · 의견 ${scores.opinion} · 감정 ${scores.manipulation}</div>`
      : '';
    const flagLine = flags.length
      ? `<div class="nfc-tip-flags">감지: ${flags.map(escapeHtml).join(', ')}</div>`
      : '';

    tooltip.innerHTML = `
      <strong>${escapeHtml(label)} ${confidence ? `· 신뢰도 ${escapeHtml(confidence)}%` : ''}</strong>
      <div>${escapeHtml(reason)}</div>
      ${scoreLine}
      ${flagLine}
    `;
    tooltip.style.display = 'block';
    moveTooltip(e);
  }

  function moveTooltip(e) {
    if (!tooltip) return;
    const x = e.clientX + window.scrollX + 14;
    const y = e.clientY + window.scrollY - 64;
    tooltip.style.left = Math.min(x, window.scrollX + window.innerWidth - 310) + 'px';
    tooltip.style.top = Math.max(y, window.scrollY + 8) + 'px';
  }

  function hideTooltip() {
    if (tooltip) tooltip.style.display = 'none';
  }

  // ============================================================
  // 하이라이트
  // ============================================================
  function removeHighlights() {
    document.querySelectorAll('.nfc-highlight').forEach(el => {
      const parent = el.parentNode;
      if (!parent) return;
      while (el.firstChild) parent.insertBefore(el.firstChild, el);
      parent.removeChild(el);
      parent.normalize();
    });
  }

  function buildNormalizedIndex(root) {
    const walker = document.createTreeWalker(root, NodeFilter.SHOW_TEXT, {
      acceptNode(node) {
        return isRejectedTextNode(node) ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
      }
    });

    let normalized = '';
    const map = [];
    let lastWasSpace = true;
    let node;

    while ((node = walker.nextNode())) {
      const text = node.nodeValue || '';
      for (let i = 0; i < text.length; i++) {
        const ch = text[i];
        if (/\s/.test(ch)) {
          if (!lastWasSpace && normalized.length > 0) {
            normalized += ' ';
            map.push({ node, offset: i });
            lastWasSpace = true;
          }
        } else {
          normalized += ch;
          map.push({ node, offset: i });
          lastWasSpace = false;
        }
      }
    }

    return { normalized, map };
  }

  function findHighlightRanges(root, sentences) {
    const { normalized, map } = buildNormalizedIndex(root);
    const ranges = [];
    let cursor = 0;

    for (const sentence of sentences) {
      const clean = Analyzer.normalizeText(sentence.text);
      if (!clean || clean.length < 6) continue;

      let target = clean;
      let idx = normalized.indexOf(target, cursor);

      if (idx === -1 && clean.length > 120) {
        target = clean.slice(0, 120);
        idx = normalized.indexOf(target, cursor);
      }
      if (idx === -1 && clean.length > 60) {
        target = clean.slice(0, 60);
        idx = normalized.indexOf(target, cursor);
      }
      if (idx === -1) {
        target = clean.slice(0, Math.min(35, clean.length));
        idx = normalized.indexOf(target);
      }
      if (idx === -1) continue;

      const start = map[idx];
      const end = map[Math.min(idx + target.length - 1, map.length - 1)];
      if (!start || !end) continue;

      ranges.push({
        start,
        end,
        startIndex: idx,
        endIndex: idx + target.length,
        sentence
      });
      cursor = idx + target.length;
    }

    // DOM 변경으로 offset이 틀어지지 않도록 뒤에서 앞으로 감싼다.
    return ranges.sort((a, b) => b.startIndex - a.startIndex);
  }

  function wrapRange(item) {
    const { start, end, sentence } = item;
    try {
      const range = document.createRange();
      range.setStart(start.node, start.offset);
      range.setEnd(end.node, end.offset + 1);

      const span = document.createElement('span');
      span.className = `nfc-highlight nfc-${sentence.type}`;
      if (sentence.type === 'manipulation' && sentence.confidence >= 70) {
        span.classList.add('nfc-high-risk');
      }

      span.dataset.nfcType = sentence.type;
      span.dataset.nfcLabel = sentence.label || sentence.type;
      span.dataset.nfcReason = sentence.reason || '';
      span.dataset.nfcConfidence = String(sentence.confidence || '');
      span.dataset.nfcScores = JSON.stringify(sentence.scores || {});
      span.dataset.nfcFlags = JSON.stringify(sentence.flags || []);

      span.addEventListener('mouseenter', e => showTooltip(e, span));
      span.addEventListener('mousemove', moveTooltip);
      span.addEventListener('mouseleave', hideTooltip);

      const contents = range.extractContents();
      span.appendChild(contents);
      range.insertNode(span);
    } catch (err) {
      // 일부 복잡한 DOM에서는 range 적용이 실패할 수 있으므로 전체 분석은 유지한다.
      console.debug('[뉴스 판별기] 하이라이트 일부 실패:', err);
    }
  }

  function applyHighlights(sentences) {
    removeHighlights();
    articleRoot = articleRoot || findArticleRoot();

    const ranges = findHighlightRanges(articleRoot, sentences);
    ranges.forEach(wrapRange);

    const summary = Analyzer.summarizeAnalysis(sentences);
    state = {
      analyzed: true,
      visible: true,
      sentences,
      stats: summary.stats,
      summary,
      articleLength: state.articleLength
    };
  }

  function toggleHighlightVisibility() {
    const els = document.querySelectorAll('.nfc-highlight');
    if (state.visible) {
      els.forEach(el => el.classList.add('nfc-hidden'));
      state.visible = false;
    } else {
      els.forEach(el => el.classList.remove('nfc-hidden'));
      state.visible = true;
    }
    return state.visible;
  }

  function runCurrentPageAnalysis() {
    const text = extractArticleText();
    if (!text || text.length < 40) {
      return { success: false, error: '기사 본문을 찾지 못했습니다. 본문 영역이 있는 뉴스 페이지에서 다시 시도해주세요.' };
    }

    const sentences = Analyzer.analyzeText(text);
    if (!sentences.length) {
      return { success: false, error: '분석할 문장을 찾지 못했습니다.' };
    }

    applyHighlights(sentences);
    return {
      success: true,
      stats: state.stats,
      summary: state.summary,
      count: sentences.length,
      articleLength: state.articleLength
    };
  }

  // ============================================================
  // 메시지 핸들러
  // ============================================================
  chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
    if (message.type === 'EXTRACT_AND_ANALYZE') {
      sendResponse(runCurrentPageAnalysis());
      return true;
    }

    if (message.type === 'EXTRACT_TEXT') {
      sendResponse({ text: extractArticleText() });
      return true;
    }

    if (message.type === 'APPLY_HIGHLIGHTS') {
      applyHighlights(message.sentences || []);
      sendResponse({ success: true, stats: state.stats, summary: state.summary });
      return true;
    }

    if (message.type === 'TOGGLE_HIGHLIGHT') {
      sendResponse({ visible: toggleHighlightVisibility() });
      return true;
    }

    if (message.type === 'GET_STATE') {
      sendResponse(state);
      return true;
    }
  });

  createTooltip();
})();
